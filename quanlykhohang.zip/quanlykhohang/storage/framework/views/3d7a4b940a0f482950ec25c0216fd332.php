
<?php $__env->startSection('main-content'); ?>
<?php $__env->startSection('title', 'StockinDetails'); ?>

<div class="container">
    <style>

    </style>
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header bg-primary text-white fw-bold text-uppercase h3">
                    <i class="ti ti-shopping-cart"></i> Đơn Hàng - <?php echo e($stockindetail->stockin->supplier->NAME); ?>

                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-5 fw-bold text-uppercase">
                            <p style="font-size: 16px; font-weight: bold;">Tên Nhà Cung Cấp:</p>
                        </div>
                        <div class="col-lg-7">
                            <p><?php echo e($stockindetail->stockin->supplier->NAME); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-5 fw-bold text-uppercase">
                            <p style="font-size: 16px; font-weight: bold;">Số Điện Thoại:</p>
                        </div>
                        <div class="col-lg-7">
                            <p>0<?php echo e($stockindetail->stockin->supplier->PHONE); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-5 fw-bold text-uppercase">
                            <p style="font-size: 16px; font-weight: bold;">Địa Chỉ:</p>
                        </div>
                        <div class="col-lg-7">
                            <p><?php echo e($stockindetail->stockin->supplier->ADDRESS); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-5 fw-bold text-uppercase">
                            <p style="font-size: 16px; font-weight: bold;">Sản Phẩm Nhập:</p>
                        </div>
                        <div class="col-lg-7">
                            <p><?php echo e($stockindetail->product->NAME); ?></p>
                            <p style="margin-top: -23px; ">
                                <?php echo e($stockindetail->QUANTITY); ?> <span style="font-size: 16px; font-weight: bold">x</span>
                                <?php echo e(number_format($stockindetail->product->PRICE, 0, ',', '.')); ?> <span
                                    style="font-size: 23px; font-weight: bold">=</span>
                                <?php echo e(number_format($stockindetail->QUANTITY * $stockindetail->product->PRICE, 0, ',', '.')); ?>₫
                            </p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-5 fw-bold text-uppercase text-success">
                            <p style="font-size: 16px; font-weight: bold;">Tổng Tiền:</p>
                        </div>
                        <div class="col-lg-7">
                            <p style="font-weight: bold; font-size: 23px">
                                <?php echo e(number_format($stockindetail->QUANTITY * $stockindetail->product->PRICE, 0, ',', '.')); ?>₫
                            </p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QuanLyKho\quanlykhohang\resources\views/backend/stockins/show_stockindetail.blade.php ENDPATH**/ ?>