<div class="py-6 px-6 text-center">
    <p class="mb-0 fs-4">Design and Developed for <a
            href="https://www.facebook.com/profile.php?id=100033585273489" target="_blank">DatGold</a></p>
</div>
<?php /**PATH C:\xampp\htdocs\QuanLyKho\quanlykhohang\resources\views/backend/layouts/footer.blade.php ENDPATH**/ ?>