<script src="<?php echo e(asset('backend/assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/sidebarmenu.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/app.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/libs/apexcharts/dist/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/libs/simplebar/dist/simplebar.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/dashboard.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/datatables.js')); ?>"></script>

<style>
    .selected-row {
        background-color: #abdde5 !important;
        /* Màu nền của dòng được chọn */
    }

    /* .selected-row:hover {
        background-color: #bef1ff !important; */
    /* Màu nền của dòng khi rê chuột vào */
</style>
<script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
</script>








<script>
    $(document).ready(function() {
        $('#myTable tbody').on('change', '.select-row', function() {
            var isChecked = $(this).prop('checked');
            var row = $(this).closest('tr');

            if (isChecked) {
                row.addClass('selected-row');
            } else {
                row.removeClass('selected-row');
            }

            updateSelectAllCheckbox();
        });

        $('.select-all').on('change', function() {
            var isChecked = $(this).prop('checked');

            $('.select-row').prop('checked', isChecked);
            $('#myTable tbody tr').toggleClass('selected-row', isChecked);
        });

        function updateSelectAllCheckbox() {
            var allSelected = $('.select-row:checked').length === $('.select-row').length;
            $('.select-all').prop('checked', allSelected);
        }
    });
</script>
<?php /**PATH C:\xampp\htdocs\QuanLyKho\quanlykhohang\resources\views/backend/layouts/footerscript.blade.php ENDPATH**/ ?>