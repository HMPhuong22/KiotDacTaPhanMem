<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin - <?php echo $__env->yieldContent('title'); ?> </title>
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('backend/assets/images/logos/favicon.png')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/styles.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/datatable.css')); ?>" />




</head>
<?php /**PATH C:\xampp\htdocs\QuanLyKho\quanlykhohang\resources\views/backend/layouts/head.blade.php ENDPATH**/ ?>