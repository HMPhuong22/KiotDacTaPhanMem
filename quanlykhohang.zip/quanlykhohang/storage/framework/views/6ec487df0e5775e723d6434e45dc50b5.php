
<?php $__env->startSection('main-content'); ?>
<?php $__env->startSection('title', 'LIST-EMPLOYEES'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h1 class="fw-semibold mb-4 text-center text-dark">LIST WAREHOUSES</h1>
                    <div class="row mb-5">
                        <div class="col-lg-8">

                        </div>
                        <div class="col-lg-4">
                            <a href="<?php echo e(route('warehouse.create')); ?>" class="btn btn-primary float-end">+ ADD
                                WAREHOUSE</a>
                        </div>
                    </div>
                    <div class="table-responsive ">
                        <table class="table table-bordered table-hover" id="myTable">
                            <thead>
                                <tr class="text-center">
                                    <th>STT</th>
                                    <th>Warehouse Name</th>
                                    <th>Warehouse Address </th>
                                    <th>Manager</th>
                                    <th>Settings</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $dem = 1; ?>
                                <?php $__currentLoopData = $warehouse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="text-center">
                                        <td><?php echo $dem++; ?></td>
                                        <td><?php echo e($data->NAME); ?></td>
                                        <td><?php echo e($data->ADDRESS); ?></td>
                                        <td>
                                            <p>
                                                <?php if($data->employee != null): ?>
                                                    <?php echo e($data->employee->LASTNAME); ?> <?php echo e($data->employee->FIRSTNAME); ?>

                                                <?php else: ?>
                                                    <p class="text-danger fw-bold ">Chưa Có Quản Lý</p>
                                                <?php endif; ?>
                                            </p>


                                        </td>
                                        <td>
                                            <span class="d-flex">
                                                
                                                <a href="<?php echo e(route('warehouse.show', ['warehouse' => $data->WAR_ID])); ?>"
                                                    class="btn btn-success text-white me-1">Edit</a>
                                                <form
                                                    action="<?php echo e(route('warehouse.destroy', ['warehouse' => $data->WAR_ID])); ?>"
                                                    method="post">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <input type="submit" class="btn btn-danger text-white"
                                                        value="Delete" />
                                                </form>
                                            </span>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QuanLyKho\quanlykhohang\resources\views/backend/warehouses/list_warehouse.blade.php ENDPATH**/ ?>